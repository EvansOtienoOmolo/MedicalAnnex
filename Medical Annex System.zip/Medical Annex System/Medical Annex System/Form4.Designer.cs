﻿namespace Medical_Annex_System
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label iDLabel;
            System.Windows.Forms.Label patient_FirstNameLabel;
            System.Windows.Forms.Label patient_Second_NameLabel;
            System.Windows.Forms.Label phone_NumberLabel;
            System.Windows.Forms.Label email_AdressLabel;
            System.Windows.Forms.Label post_codeLabel;
            System.Windows.Forms.Label home_PhoneLabel;
            System.Windows.Forms.Label date_of_BirthLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.pharmacy_OfficeDataSet = new Medical_Annex_System.Pharmacy_OfficeDataSet();
            this.paientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.paientTableAdapter = new Medical_Annex_System.Pharmacy_OfficeDataSetTableAdapters.PaientTableAdapter();
            this.tableAdapterManager = new Medical_Annex_System.Pharmacy_OfficeDataSetTableAdapters.TableAdapterManager();
            this.paientBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.paientBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.iDTextBox = new System.Windows.Forms.TextBox();
            this.patient_FirstNameTextBox = new System.Windows.Forms.TextBox();
            this.patient_Second_NameTextBox = new System.Windows.Forms.TextBox();
            this.phone_NumberTextBox = new System.Windows.Forms.TextBox();
            this.email_AdressTextBox = new System.Windows.Forms.TextBox();
            this.post_codeTextBox = new System.Windows.Forms.TextBox();
            this.home_PhoneTextBox = new System.Windows.Forms.TextBox();
            this.date_of_BirthDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            iDLabel = new System.Windows.Forms.Label();
            patient_FirstNameLabel = new System.Windows.Forms.Label();
            patient_Second_NameLabel = new System.Windows.Forms.Label();
            phone_NumberLabel = new System.Windows.Forms.Label();
            email_AdressLabel = new System.Windows.Forms.Label();
            post_codeLabel = new System.Windows.Forms.Label();
            home_PhoneLabel = new System.Windows.Forms.Label();
            date_of_BirthLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pharmacy_OfficeDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paientBindingNavigator)).BeginInit();
            this.paientBindingNavigator.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // iDLabel
            // 
            iDLabel.AutoSize = true;
            iDLabel.Location = new System.Drawing.Point(148, 182);
            iDLabel.Name = "iDLabel";
            iDLabel.Size = new System.Drawing.Size(21, 13);
            iDLabel.TabIndex = 1;
            iDLabel.Text = "ID:";
            // 
            // patient_FirstNameLabel
            // 
            patient_FirstNameLabel.AutoSize = true;
            patient_FirstNameLabel.Location = new System.Drawing.Point(148, 208);
            patient_FirstNameLabel.Name = "patient_FirstNameLabel";
            patient_FirstNameLabel.Size = new System.Drawing.Size(96, 13);
            patient_FirstNameLabel.TabIndex = 3;
            patient_FirstNameLabel.Text = "Patient First Name:";
            // 
            // patient_Second_NameLabel
            // 
            patient_Second_NameLabel.AutoSize = true;
            patient_Second_NameLabel.Location = new System.Drawing.Point(148, 234);
            patient_Second_NameLabel.Name = "patient_Second_NameLabel";
            patient_Second_NameLabel.Size = new System.Drawing.Size(114, 13);
            patient_Second_NameLabel.TabIndex = 5;
            patient_Second_NameLabel.Text = "Patient Second Name:";
            // 
            // phone_NumberLabel
            // 
            phone_NumberLabel.AutoSize = true;
            phone_NumberLabel.Location = new System.Drawing.Point(148, 260);
            phone_NumberLabel.Name = "phone_NumberLabel";
            phone_NumberLabel.Size = new System.Drawing.Size(81, 13);
            phone_NumberLabel.TabIndex = 7;
            phone_NumberLabel.Text = "Phone Number:";
            // 
            // email_AdressLabel
            // 
            email_AdressLabel.AutoSize = true;
            email_AdressLabel.Location = new System.Drawing.Point(148, 286);
            email_AdressLabel.Name = "email_AdressLabel";
            email_AdressLabel.Size = new System.Drawing.Size(70, 13);
            email_AdressLabel.TabIndex = 9;
            email_AdressLabel.Text = "Email Adress:";
            // 
            // post_codeLabel
            // 
            post_codeLabel.AutoSize = true;
            post_codeLabel.Location = new System.Drawing.Point(148, 312);
            post_codeLabel.Name = "post_codeLabel";
            post_codeLabel.Size = new System.Drawing.Size(57, 13);
            post_codeLabel.TabIndex = 11;
            post_codeLabel.Text = "post code:";
            // 
            // home_PhoneLabel
            // 
            home_PhoneLabel.AutoSize = true;
            home_PhoneLabel.Location = new System.Drawing.Point(148, 338);
            home_PhoneLabel.Name = "home_PhoneLabel";
            home_PhoneLabel.Size = new System.Drawing.Size(72, 13);
            home_PhoneLabel.TabIndex = 13;
            home_PhoneLabel.Text = "Home Phone:";
            // 
            // date_of_BirthLabel
            // 
            date_of_BirthLabel.AutoSize = true;
            date_of_BirthLabel.Location = new System.Drawing.Point(148, 365);
            date_of_BirthLabel.Name = "date_of_BirthLabel";
            date_of_BirthLabel.Size = new System.Drawing.Size(69, 13);
            date_of_BirthLabel.TabIndex = 15;
            date_of_BirthLabel.Text = "Date of Birth:";
            // 
            // pharmacy_OfficeDataSet
            // 
            this.pharmacy_OfficeDataSet.DataSetName = "Pharmacy_OfficeDataSet";
            this.pharmacy_OfficeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // paientBindingSource
            // 
            this.paientBindingSource.DataMember = "Paient";
            this.paientBindingSource.DataSource = this.pharmacy_OfficeDataSet;
            // 
            // paientTableAdapter
            // 
            this.paientTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DoctorTableAdapter = null;
            this.tableAdapterManager.GP_AppointmentTableAdapter = null;
            this.tableAdapterManager.PaientTableAdapter = this.paientTableAdapter;
            this.tableAdapterManager.PaymentTableAdapter = null;
            this.tableAdapterManager.PharmacyTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Medical_Annex_System.Pharmacy_OfficeDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // paientBindingNavigator
            // 
            this.paientBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.paientBindingNavigator.BindingSource = this.paientBindingSource;
            this.paientBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.paientBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.paientBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.paientBindingNavigatorSaveItem});
            this.paientBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.paientBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.paientBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.paientBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.paientBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.paientBindingNavigator.Name = "paientBindingNavigator";
            this.paientBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.paientBindingNavigator.Size = new System.Drawing.Size(784, 25);
            this.paientBindingNavigator.TabIndex = 0;
            this.paientBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // paientBindingNavigatorSaveItem
            // 
            this.paientBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.paientBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("paientBindingNavigatorSaveItem.Image")));
            this.paientBindingNavigatorSaveItem.Name = "paientBindingNavigatorSaveItem";
            this.paientBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.paientBindingNavigatorSaveItem.Text = "Save Data";
            this.paientBindingNavigatorSaveItem.Click += new System.EventHandler(this.paientBindingNavigatorSaveItem_Click);
            // 
            // iDTextBox
            // 
            this.iDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paientBindingSource, "ID", true));
            this.iDTextBox.Location = new System.Drawing.Point(268, 179);
            this.iDTextBox.Name = "iDTextBox";
            this.iDTextBox.Size = new System.Drawing.Size(312, 20);
            this.iDTextBox.TabIndex = 2;
            // 
            // patient_FirstNameTextBox
            // 
            this.patient_FirstNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paientBindingSource, "Patient FirstName", true));
            this.patient_FirstNameTextBox.Location = new System.Drawing.Point(268, 205);
            this.patient_FirstNameTextBox.Name = "patient_FirstNameTextBox";
            this.patient_FirstNameTextBox.Size = new System.Drawing.Size(312, 20);
            this.patient_FirstNameTextBox.TabIndex = 4;
            // 
            // patient_Second_NameTextBox
            // 
            this.patient_Second_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paientBindingSource, "Patient Second Name", true));
            this.patient_Second_NameTextBox.Location = new System.Drawing.Point(268, 231);
            this.patient_Second_NameTextBox.Name = "patient_Second_NameTextBox";
            this.patient_Second_NameTextBox.Size = new System.Drawing.Size(312, 20);
            this.patient_Second_NameTextBox.TabIndex = 6;
            // 
            // phone_NumberTextBox
            // 
            this.phone_NumberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paientBindingSource, "Phone Number", true));
            this.phone_NumberTextBox.Location = new System.Drawing.Point(268, 257);
            this.phone_NumberTextBox.Name = "phone_NumberTextBox";
            this.phone_NumberTextBox.Size = new System.Drawing.Size(312, 20);
            this.phone_NumberTextBox.TabIndex = 8;
            // 
            // email_AdressTextBox
            // 
            this.email_AdressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paientBindingSource, "Email Adress", true));
            this.email_AdressTextBox.Location = new System.Drawing.Point(268, 283);
            this.email_AdressTextBox.Name = "email_AdressTextBox";
            this.email_AdressTextBox.Size = new System.Drawing.Size(312, 20);
            this.email_AdressTextBox.TabIndex = 10;
            // 
            // post_codeTextBox
            // 
            this.post_codeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paientBindingSource, "post code", true));
            this.post_codeTextBox.Location = new System.Drawing.Point(268, 309);
            this.post_codeTextBox.Name = "post_codeTextBox";
            this.post_codeTextBox.Size = new System.Drawing.Size(312, 20);
            this.post_codeTextBox.TabIndex = 12;
            // 
            // home_PhoneTextBox
            // 
            this.home_PhoneTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paientBindingSource, "Home Phone", true));
            this.home_PhoneTextBox.Location = new System.Drawing.Point(268, 335);
            this.home_PhoneTextBox.Name = "home_PhoneTextBox";
            this.home_PhoneTextBox.Size = new System.Drawing.Size(312, 20);
            this.home_PhoneTextBox.TabIndex = 14;
            // 
            // date_of_BirthDateTimePicker
            // 
            this.date_of_BirthDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.paientBindingSource, "Date of Birth", true));
            this.date_of_BirthDateTimePicker.Location = new System.Drawing.Point(268, 361);
            this.date_of_BirthDateTimePicker.Name = "date_of_BirthDateTimePicker";
            this.date_of_BirthDateTimePicker.Size = new System.Drawing.Size(312, 20);
            this.date_of_BirthDateTimePicker.TabIndex = 16;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(17, 28);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(750, 111);
            this.panel2.TabIndex = 17;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(26, 15);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 85);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label3.Location = new System.Drawing.Point(265, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(246, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "PATIENT DETAILS";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.panel2);
            this.Controls.Add(iDLabel);
            this.Controls.Add(this.iDTextBox);
            this.Controls.Add(patient_FirstNameLabel);
            this.Controls.Add(this.patient_FirstNameTextBox);
            this.Controls.Add(patient_Second_NameLabel);
            this.Controls.Add(this.patient_Second_NameTextBox);
            this.Controls.Add(phone_NumberLabel);
            this.Controls.Add(this.phone_NumberTextBox);
            this.Controls.Add(email_AdressLabel);
            this.Controls.Add(this.email_AdressTextBox);
            this.Controls.Add(post_codeLabel);
            this.Controls.Add(this.post_codeTextBox);
            this.Controls.Add(home_PhoneLabel);
            this.Controls.Add(this.home_PhoneTextBox);
            this.Controls.Add(date_of_BirthLabel);
            this.Controls.Add(this.date_of_BirthDateTimePicker);
            this.Controls.Add(this.paientBindingNavigator);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form4";
            this.Text = "Patient";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pharmacy_OfficeDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paientBindingNavigator)).EndInit();
            this.paientBindingNavigator.ResumeLayout(false);
            this.paientBindingNavigator.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Pharmacy_OfficeDataSet pharmacy_OfficeDataSet;
        private System.Windows.Forms.BindingSource paientBindingSource;
        private Pharmacy_OfficeDataSetTableAdapters.PaientTableAdapter paientTableAdapter;
        private Pharmacy_OfficeDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator paientBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton paientBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox iDTextBox;
        private System.Windows.Forms.TextBox patient_FirstNameTextBox;
        private System.Windows.Forms.TextBox patient_Second_NameTextBox;
        private System.Windows.Forms.TextBox phone_NumberTextBox;
        private System.Windows.Forms.TextBox email_AdressTextBox;
        private System.Windows.Forms.TextBox post_codeTextBox;
        private System.Windows.Forms.TextBox home_PhoneTextBox;
        private System.Windows.Forms.DateTimePicker date_of_BirthDateTimePicker;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
    }
}