﻿namespace Medical_Annex_System
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnDoctor = new System.Windows.Forms.Button();
            this.btnGP = new System.Windows.Forms.Button();
            this.btnPatient = new System.Windows.Forms.Button();
            this.btnPayment = new System.Windows.Forms.Button();
            this.btnPharmacy = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.btnPharmacy_office = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnPH = new System.Windows.Forms.Button();
            this.btnHelp = new System.Windows.Forms.Button();
            this.btnphamacy = new System.Windows.Forms.Button();
            this.btnConsultant = new System.Windows.Forms.Button();
            this.btnSpecialist = new System.Windows.Forms.Button();
            this.btnHospital = new System.Windows.Forms.Button();
            this.btnAdmin = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDoctor
            // 
            this.btnDoctor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDoctor.Location = new System.Drawing.Point(15, 154);
            this.btnDoctor.Margin = new System.Windows.Forms.Padding(6);
            this.btnDoctor.Name = "btnDoctor";
            this.btnDoctor.Size = new System.Drawing.Size(175, 43);
            this.btnDoctor.TabIndex = 0;
            this.btnDoctor.Text = "Doctor";
            this.btnDoctor.UseVisualStyleBackColor = true;
            this.btnDoctor.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnGP
            // 
            this.btnGP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGP.Location = new System.Drawing.Point(15, 209);
            this.btnGP.Margin = new System.Windows.Forms.Padding(6);
            this.btnGP.Name = "btnGP";
            this.btnGP.Size = new System.Drawing.Size(175, 43);
            this.btnGP.TabIndex = 1;
            this.btnGP.Text = "GP Appointment";
            this.btnGP.UseVisualStyleBackColor = true;
            this.btnGP.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnPatient
            // 
            this.btnPatient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPatient.Location = new System.Drawing.Point(15, 264);
            this.btnPatient.Margin = new System.Windows.Forms.Padding(6);
            this.btnPatient.Name = "btnPatient";
            this.btnPatient.Size = new System.Drawing.Size(175, 43);
            this.btnPatient.TabIndex = 2;
            this.btnPatient.Text = "Patient";
            this.btnPatient.UseVisualStyleBackColor = true;
            this.btnPatient.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnPayment
            // 
            this.btnPayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPayment.Location = new System.Drawing.Point(15, 319);
            this.btnPayment.Margin = new System.Windows.Forms.Padding(6);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(175, 43);
            this.btnPayment.TabIndex = 3;
            this.btnPayment.Text = "Payment";
            this.btnPayment.UseVisualStyleBackColor = true;
            this.btnPayment.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnPharmacy
            // 
            this.btnPharmacy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPharmacy.Location = new System.Drawing.Point(15, 374);
            this.btnPharmacy.Margin = new System.Windows.Forms.Padding(6);
            this.btnPharmacy.Name = "btnPharmacy";
            this.btnPharmacy.Size = new System.Drawing.Size(175, 43);
            this.btnPharmacy.TabIndex = 4;
            this.btnPharmacy.Text = "Pharmacy";
            this.btnPharmacy.UseVisualStyleBackColor = true;
            this.btnPharmacy.Click += new System.EventHandler(this.button5_Click);
            // 
            // button7
            // 
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(15, 505);
            this.button7.Margin = new System.Windows.Forms.Padding(6);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(175, 43);
            this.button7.TabIndex = 6;
            this.button7.Text = "Exit";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Controls.Add(this.btnLogin);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtPassword);
            this.panel1.Controls.Add(this.txtUsername);
            this.panel1.Location = new System.Drawing.Point(218, 135);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(608, 429);
            this.panel1.TabIndex = 7;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(277, 17);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(66, 61);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // btnClear
            // 
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Location = new System.Drawing.Point(394, 356);
            this.btnClear.Margin = new System.Windows.Forms.Padding(6);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(112, 43);
            this.btnClear.TabIndex = 8;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnLogin
            // 
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.Location = new System.Drawing.Point(100, 356);
            this.btnLogin.Margin = new System.Windows.Forms.Padding(6);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(117, 43);
            this.btnLogin.TabIndex = 7;
            this.btnLogin.Text = "Log in";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.button8_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 264);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "Password";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 136);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Name";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(302, 255);
            this.txtPassword.Multiline = true;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(204, 45);
            this.txtPassword.TabIndex = 1;
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(302, 125);
            this.txtUsername.Multiline = true;
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(204, 45);
            this.txtUsername.TabIndex = 0;
            this.txtUsername.TextChanged += new System.EventHandler(this.txtUsername_TextChanged);
            // 
            // btnPharmacy_office
            // 
            this.btnPharmacy_office.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPharmacy_office.Location = new System.Drawing.Point(15, 429);
            this.btnPharmacy_office.Margin = new System.Windows.Forms.Padding(6);
            this.btnPharmacy_office.Name = "btnPharmacy_office";
            this.btnPharmacy_office.Size = new System.Drawing.Size(175, 43);
            this.btnPharmacy_office.TabIndex = 8;
            this.btnPharmacy_office.Text = "Pharmacy Office";
            this.btnPharmacy_office.UseVisualStyleBackColor = true;
            this.btnPharmacy_office.Click += new System.EventHandler(this.btnPharmacy_office_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(86, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(919, 117);
            this.panel2.TabIndex = 9;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(26, 15);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 85);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label3.Location = new System.Drawing.Point(177, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(470, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "KISII UNIVERSITY MEDICAL ANNEX";
            // 
            // btnPH
            // 
            this.btnPH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPH.Location = new System.Drawing.Point(865, 392);
            this.btnPH.Margin = new System.Windows.Forms.Padding(6);
            this.btnPH.Name = "btnPH";
            this.btnPH.Size = new System.Drawing.Size(175, 43);
            this.btnPH.TabIndex = 16;
            this.btnPH.Text = "PH Firm";
            this.btnPH.UseVisualStyleBackColor = true;
            // 
            // btnHelp
            // 
            this.btnHelp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHelp.Location = new System.Drawing.Point(865, 505);
            this.btnHelp.Margin = new System.Windows.Forms.Padding(6);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(175, 43);
            this.btnHelp.TabIndex = 15;
            this.btnHelp.Text = "Help";
            this.btnHelp.UseVisualStyleBackColor = true;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // btnphamacy
            // 
            this.btnphamacy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnphamacy.Location = new System.Drawing.Point(865, 337);
            this.btnphamacy.Margin = new System.Windows.Forms.Padding(6);
            this.btnphamacy.Name = "btnphamacy";
            this.btnphamacy.Size = new System.Drawing.Size(175, 43);
            this.btnphamacy.TabIndex = 14;
            this.btnphamacy.Text = "Pharmacist";
            this.btnphamacy.UseVisualStyleBackColor = true;
            // 
            // btnConsultant
            // 
            this.btnConsultant.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConsultant.Location = new System.Drawing.Point(865, 282);
            this.btnConsultant.Margin = new System.Windows.Forms.Padding(6);
            this.btnConsultant.Name = "btnConsultant";
            this.btnConsultant.Size = new System.Drawing.Size(175, 43);
            this.btnConsultant.TabIndex = 13;
            this.btnConsultant.Text = "Consultant";
            this.btnConsultant.UseVisualStyleBackColor = true;
            // 
            // btnSpecialist
            // 
            this.btnSpecialist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSpecialist.Location = new System.Drawing.Point(865, 227);
            this.btnSpecialist.Margin = new System.Windows.Forms.Padding(6);
            this.btnSpecialist.Name = "btnSpecialist";
            this.btnSpecialist.Size = new System.Drawing.Size(175, 43);
            this.btnSpecialist.TabIndex = 12;
            this.btnSpecialist.Text = "Specialist";
            this.btnSpecialist.UseVisualStyleBackColor = true;
            // 
            // btnHospital
            // 
            this.btnHospital.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHospital.Location = new System.Drawing.Point(865, 172);
            this.btnHospital.Margin = new System.Windows.Forms.Padding(6);
            this.btnHospital.Name = "btnHospital";
            this.btnHospital.Size = new System.Drawing.Size(175, 43);
            this.btnHospital.TabIndex = 11;
            this.btnHospital.Text = "Hospital";
            this.btnHospital.UseVisualStyleBackColor = true;
            // 
            // btnAdmin
            // 
            this.btnAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdmin.Location = new System.Drawing.Point(865, 450);
            this.btnAdmin.Margin = new System.Windows.Forms.Padding(6);
            this.btnAdmin.Name = "btnAdmin";
            this.btnAdmin.Size = new System.Drawing.Size(175, 43);
            this.btnAdmin.TabIndex = 10;
            this.btnAdmin.Text = "Admin";
            this.btnAdmin.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1056, 620);
            this.Controls.Add(this.btnPH);
            this.Controls.Add(this.btnHelp);
            this.Controls.Add(this.btnphamacy);
            this.Controls.Add(this.btnConsultant);
            this.Controls.Add(this.btnSpecialist);
            this.Controls.Add(this.btnHospital);
            this.Controls.Add(this.btnAdmin);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnPharmacy_office);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.btnPharmacy);
            this.Controls.Add(this.btnPayment);
            this.Controls.Add(this.btnPatient);
            this.Controls.Add(this.btnGP);
            this.Controls.Add(this.btnDoctor);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "MEDICAL ANNEX";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnDoctor;
        private System.Windows.Forms.Button btnGP;
        private System.Windows.Forms.Button btnPatient;
        private System.Windows.Forms.Button btnPayment;
        private System.Windows.Forms.Button btnPharmacy;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Button btnPharmacy_office;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnPH;
        private System.Windows.Forms.Button btnHelp;
        private System.Windows.Forms.Button btnphamacy;
        private System.Windows.Forms.Button btnConsultant;
        private System.Windows.Forms.Button btnSpecialist;
        private System.Windows.Forms.Button btnHospital;
        private System.Windows.Forms.Button btnAdmin;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

